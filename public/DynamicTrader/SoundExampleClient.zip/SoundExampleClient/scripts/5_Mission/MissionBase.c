modded class MissionBase {

    override void OnInit() {
        super.OnInit();

        //Get instance of TBTDSoundCollection
        TBTDSoundCollection collection = TBTDSoundCollection.Get();

        // -------------------------------------------------------------------------
        // Example: Adding a completely new custom sound
        // -------------------------------------------------------------------------
        // 1. Add the base sound for the default language (e.g., english).
        // The AddSound method returns the assigned integer ID (soundIndex) for your new sound,
        // which you need to store or use if you want to add more languages for it.
        // Parameters: language, soundSetNameMale, soundSetNameFemale, soundInternalName
        // "english", // Language of the sound ("english", "german", "chinesesimp", "chinese", "russian", "czech", "polish", "hungarian", "italian", "spanish", "french", "portuguese", "japanese")
        // "TBDT_MyCustomSound_English_Male_SoundSet", // SoundSet for male voice
        // "TBDT_MyCustomSound_English_Female_SoundSet", // SoundSet for female voice
        // "my_custom_sound" // Internal name of the sound, will shown in menu for example

        int myCustomSoundIndex = collection.AddSound("english", "TBDT_MyCustomSound_English_Male_SoundSet", "TBDT_MyCustomSound_English_Female_SoundSet", "my_custom_sound");

        // 2. Add an additional language for the custom sound we just created.
        // We use the soundIndex returned by AddSound to link the new language translation.
        // Parameters: soundIndex, language, soundSetNameMale, soundSetNameFemale
        // "german", // Language of the sound
        // "TBDT_MyCustomSound_German_Male_SoundSet", // SoundSet for male voice
        // "TBDT_MyCustomSound_German_Female_SoundSet" // SoundSet for female voice
        collection.AddAnotherLanguageForSound(myCustomSoundIndex, "german", "TBDT_MyCustomSound_German_Male_SoundSet", "TBDT_MyCustomSound_German_Female_SoundSet");

    }
}
