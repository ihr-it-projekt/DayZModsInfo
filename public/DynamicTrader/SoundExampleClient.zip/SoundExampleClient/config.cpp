class CfgPatches {
    class SoundExampleClient {
        units[] = {};
        weapons[] = {};
        requiredVersion = 0.1;
        requiredAddons[] = {
            "DZ_Data",
            "TBDynamicTraderClient"
        };
    };
};

class CfgMods {
    class SoundExampleClient {
        dir = "SoundExampleClient";
        picture = "";
        action = "";
        hideName = 1;
        hidePicture = 1;
        name = "TBDT Example Sound Mod";
        credits = "Your Name";
        author = "Your Name";
        authorID = "0";
        version = "1.0";
        extra = 0;
        type = "mod";

        dependencies[] = { "Mission" };

        class defs {
            class missionScriptModule {
                value = "";
                files[] = {
                    "SoundExampleClient/scripts/5_Mission"
                };
            };
        };
    };
};

class CfgSoundShaders {
    class TBDT_ExampleSound_Base_SoundShader {
        range = 20;
        volume = 1;
    };

    class TBDT_MyCustomSound_English_Male_SoundShader : TBDT_ExampleSound_Base_SoundShader {
        samples[] = {{"SoundExampleClient\data\sounds\my_custom_sound_en_m.ogg", 1}};
    };
    class TBDT_MyCustomSound_English_Female_SoundShader : TBDT_ExampleSound_Base_SoundShader {
        samples[] = {{"SoundExampleClient\data\sounds\my_custom_sound_en_f.ogg", 1}};
    };

    class TBDT_MyCustomSound_German_Male_SoundShader : TBDT_ExampleSound_Base_SoundShader {
        samples[] = {{"SoundExampleClient\data\sounds\my_custom_sound_de_m.ogg", 1}};
    };
    class TBDT_MyCustomSound_German_Female_SoundShader : TBDT_ExampleSound_Base_SoundShader {
        samples[] = {{"SoundExampleClient\data\sounds\my_custom_sound_de_f.ogg", 1}};
    };
};

class CfgSoundSets {
    class TBDT_ExampleSound_Base_SoundSet {
        volumeCustom = 1;
        volumeFactor = 1;
        spatial = 1;
        loop = 0;
    };

    class TBDT_MyCustomSound_English_Male_SoundSet : TBDT_ExampleSound_Base_SoundSet {
        soundShaders[] = {"TBDT_MyCustomSound_English_Male_SoundShader"};
    };
    class TBDT_MyCustomSound_English_Female_SoundSet : TBDT_ExampleSound_Base_SoundSet {
        soundShaders[] = {"TBDT_MyCustomSound_English_Female_SoundShader"};
    };

    class TBDT_MyCustomSound_German_Male_SoundSet : TBDT_ExampleSound_Base_SoundSet {
        soundShaders[] = {"TBDT_MyCustomSound_German_Male_SoundShader"};
    };
    class TBDT_MyCustomSound_German_Female_SoundSet : TBDT_ExampleSound_Base_SoundSet {
        soundShaders[] = {"TBDT_MyCustomSound_German_Female_SoundShader"};
    };
};